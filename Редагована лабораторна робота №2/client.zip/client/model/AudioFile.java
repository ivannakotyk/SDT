package com.ivanka.audioeditor.client.model;

public class AudioFile {
}
